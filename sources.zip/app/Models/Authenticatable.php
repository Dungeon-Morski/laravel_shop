<?php


namespace App\Models;

class Authenticatable
{

}
