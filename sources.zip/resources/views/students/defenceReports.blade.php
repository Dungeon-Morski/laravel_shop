{{--@extends('layouts.main')--}}
{{--@section('content')--}}
{{--    <div class="container">--}}
{{--        <div class="project__type flex">--}}
{{--            <form action="" method="" class="">--}}
{{--                <button type="submit" class="active">Курсовые</button>--}}
{{--            </form>--}}
{{--            <form action="" method="">--}}
{{--                <button type="submit" class="">Диплом</button>--}}
{{--            </form>--}}
{{--        </div>--}}
{{--        <div class="project__list">--}}
{{--            <div class="project__card">--}}
{{--                <div class="left">--}}
{{--                    <div>--}}
{{--                        <p>Дисциплина: <span>МДК 09.01</span></p>--}}
{{--                        <p>Преподаватель: <span>Усманов М.А.</span></p>--}}
{{--                        <p>Дата начала: <span>03.09.2023</span></p>--}}
{{--                        <p>Дата окончания: <span>01.10.2023</span></p>--}}
{{--                    </div>--}}
{{--                    <div class="flex status__block justify-between flex-wrap gap-4">--}}
{{--                        <div class="flex items-center gap-2">--}}
{{--                            <p>Подпись</p>--}}
{{--                            <div class="status not_signed"></div>--}}
{{--                        </div>--}}
{{--                        <div class="flex gap-4 flex-wrap">--}}
{{--                            <p>Дата загрузки: <span>01.10.2023</span></p>--}}
{{--                            <a href="">Скачать файл</a>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <form method="post" enctype="multipart/form-data" class="upload min-h-full relative">--}}

{{--                    <input type="file" name="file" class="">--}}
{{--                    <div class="as absolute flex flex-col items-center gap-2">--}}
{{--                        <img src="images/upload.svg" alt="">--}}
{{--                        <span class="">Перетащите файлы сюда или нажмите, чтобы загрузить</span>--}}
{{--                    </div>--}}

{{--                </form>--}}
{{--            </div>--}}
{{--            <div class="project__card ">--}}
{{--                <div class="left">--}}
{{--                    <div>--}}
{{--                        <p>Дисциплина: <span>МДК 09.01</span></p>--}}
{{--                        <p>Преподаватель: <span>Усманов М.А.</span></p>--}}
{{--                        <p>Дата начала: <span>03.09.2023</span></p>--}}
{{--                        <p>Дата окончания: <span>01.10.2023</span></p>--}}
{{--                    </div>--}}
{{--                    <div class="flex status__block justify-between flex-wrap gap-4">--}}
{{--                        <div class="flex items-center gap-2">--}}
{{--                            <p>Подпись</p>--}}
{{--                            <div class="status signed"></div>--}}
{{--                        </div>--}}
{{--                        <div class="flex gap-4 flex-wrap">--}}
{{--                            <p>Дата загрузки: <span>01.10.2023</span></p>--}}
{{--                            <a href="">Скачать файл</a>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <form method="post" enctype="multipart/form-data" class="upload min-h-full relative">--}}

{{--                    <input type="file" name="file" class="">--}}
{{--                    <div class="as absolute flex flex-col items-center gap-2">--}}
{{--                        <img src="images/upload.svg" alt="">--}}
{{--                        <span class="">Перетащите файлы сюда или нажмите, чтобы загрузить</span>--}}
{{--                    </div>--}}

{{--                </form>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--@endsection--}}
