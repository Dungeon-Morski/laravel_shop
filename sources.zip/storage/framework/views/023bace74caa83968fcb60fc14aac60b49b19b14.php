<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mt-5">Дисциплины отчета</h1>
        <div class="control__block">
            <a href="#" class="createBtn">Создать дисциплину отчета</a>
        </div>

        <div style="background: #6162FD" ; class="reportDisciplines_filter__block  my-4 py-2 px-2 rounded">
            <form action="<?php echo e(route('report-disciplines.index')); ?>" method="get"
                  class="flex gap-2 flex-col sm:flex-row items-center w-full">
                <?php echo csrf_field(); ?>
                <div class="flex items-center gap-2 w-full max-w-auto flex-col sm:flex-row">
                    <select name="discipline_id" id="discipline_id" class="p-0 px-2 py-1 rounded w-full">
                        <option name="discipline_id" value="">Выберите дисциплину</option>
                        <?php $__currentLoopData = $disciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option name="discipline_id" value="<?php echo e($discipline->id); ?>"><?php echo e($discipline->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="flex items-center gap-2  w-full max-w-auto flex-col sm:flex-row">

                    <select name="report_id" id="report_id" class="p-0 px-2 py-1 rounded w-full">
                        <option name="report_id" value="">Выберите вид отчета</option>
                        <?php $__currentLoopData = $reportTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option name="report_id" value="<?php echo e($reportType->id); ?>"><?php echo e($reportType->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="flex items-center gap-2  w-full max-w-auto flex-col sm:flex-row">
                    <select name="group_id" id="group_id" class="p-0 px-2 py-1 rounded w-full">
                        <option name="group_id" value="">Выберите группу</option>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option name="group_id" value="<?php echo e($group->id); ?>"><?php echo e($group->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="flex items-center gap-2  w-full max-w-auto flex-col sm:flex-row">
                    <select name="user_id" id="user_id" class="p-0 px-2 py-1 rounded w-full">
                        <option name="user_id" value="">Выберите руководителя</option>
                        <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option name="user_id"
                                    value="<?php echo e($manager->id); ?>"><?php echo e($manager->surname); ?> <?php echo e($manager->name); ?> <?php echo e($manager->patronymic); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="flex w-full items-center justify-end gap-2">
                    <a href="<?php echo e(route('report-disciplines.index')); ?>"
                       class="text-center bg-gray-50 px-3 py-1.5 h-max rounded  w-full sm:w-auto hover:no-underline">Сбросить
                    </a>
                    <button type="submit" class="bg-gray-50 px-3 py-1.5 h-max rounded  w-full sm:w-auto" value="type"
                            name="type">Поиск
                    </button>
                </div>
            </form>
        </div>

        <div class="table__block">
            <table class="info__table border">
                <thead>
                <tr>
                    <td>Дисциплина</td>
                    <td>Вид отчета</td>
                    <td>Группа</td>
                    <td>Руководитель</td>
                    <td>Запланированная дата</td>
                    <td>Управление</td>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $reportDisciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportDiscipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <form action="<?php echo e(route('report-discipline.edit',$reportDiscipline->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>

                            <td>
                                <div class="select_div">
                                    <select name="discipline_id" id="discipline_id" class="w-[200px] rounded p-0 px-2 !bg-black rounded p-0 px-2 !bg-black">
                                        <option name="discipline_id" value="<?php echo e($reportDiscipline->discipline->id); ?>" selected><?php echo e($reportDiscipline->discipline->title); ?></option>
                                        <?php $__currentLoopData = $disciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="discipline_id" value="<?php echo e($discipline->id); ?>"><?php echo e($discipline->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <svg class="" fill="#000000" width="64px" height="64px" viewBox="-3.2 -3.2 38.40 38.40" version="1.1" xmlns="http://www.w3.org/2000/svg" transform="matrix(1, 0, 0, 1, 0, 0)rotate(0)"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round" stroke="#CCCCCC" stroke-width="0.064"></g><g id="SVGRepo_iconCarrier"> <path d="M0.256 8.606c0-0.269 0.106-0.544 0.313-0.75 0.412-0.412 1.087-0.412 1.5 0l14.119 14.119 13.913-13.912c0.413-0.412 1.087-0.412 1.5 0s0.413 1.088 0 1.5l-14.663 14.669c-0.413 0.413-1.088 0.413-1.5 0l-14.869-14.869c-0.213-0.213-0.313-0.481-0.313-0.756z"></path> </g></svg>
                                </div>
                            </td>
                            <td>
                                <div class="select_div">
                                    <select name="report_id" id="report_id" class="w-[150px] rounded p-0 px-2 !bg-black">
                                        <option name="report_id" value="<?php echo e($reportDiscipline->reportType->id); ?>" selected><?php echo e($reportDiscipline->reportType->title); ?></option>
                                        <?php $__currentLoopData = $reportTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="report_id" value="<?php echo e($reportType->id); ?>"><?php echo e($reportType->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <svg class="" fill="#000000" width="64px" height="64px" viewBox="-3.2 -3.2 38.40 38.40" version="1.1" xmlns="http://www.w3.org/2000/svg" transform="matrix(1, 0, 0, 1, 0, 0)rotate(0)"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round" stroke="#CCCCCC" stroke-width="0.064"></g><g id="SVGRepo_iconCarrier"> <path d="M0.256 8.606c0-0.269 0.106-0.544 0.313-0.75 0.412-0.412 1.087-0.412 1.5 0l14.119 14.119 13.913-13.912c0.413-0.412 1.087-0.412 1.5 0s0.413 1.088 0 1.5l-14.663 14.669c-0.413 0.413-1.088 0.413-1.5 0l-14.869-14.869c-0.213-0.213-0.313-0.481-0.313-0.756z"></path> </g></svg>
                                </div>
                            </td>
                            <td>
                                <div class="select_div">
                                    <select name="group_id" id="group_id" class="w-[100px] rounded p-0 px-2 !bg-black">
                                        <option name="group_id" value="<?php echo e($reportDiscipline->group->id); ?>" selected><?php echo e($reportDiscipline->group->title); ?></option>
                                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="group_id" value="<?php echo e($group->id); ?>"><?php echo e($group->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <svg class="" fill="#000000" width="64px" height="64px" viewBox="-3.2 -3.2 38.40 38.40" version="1.1" xmlns="http://www.w3.org/2000/svg" transform="matrix(1, 0, 0, 1, 0, 0)rotate(0)"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round" stroke="#CCCCCC" stroke-width="0.064"></g><g id="SVGRepo_iconCarrier"> <path d="M0.256 8.606c0-0.269 0.106-0.544 0.313-0.75 0.412-0.412 1.087-0.412 1.5 0l14.119 14.119 13.913-13.912c0.413-0.412 1.087-0.412 1.5 0s0.413 1.088 0 1.5l-14.663 14.669c-0.413 0.413-1.088 0.413-1.5 0l-14.869-14.869c-0.213-0.213-0.313-0.481-0.313-0.756z"></path> </g></svg>
                                </div>
                            </td>
                            <td>
                                <div class="select_div">
                                    <select name="user_id" id="user_id" class="rounded p-0 px-2 !bg-black">
                                        <option name="user_id" value="<?php echo e($reportDiscipline->teacher->id); ?>" selected><?php echo e($reportDiscipline->teacher->surname); ?> <?php echo e($reportDiscipline->teacher->name); ?> <?php echo e($reportDiscipline->teacher->patronymic); ?></option>

                                        <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="user_id" value="<?php echo e($manager->id); ?>"><?php echo e($manager->surname); ?> <?php echo e($manager->name); ?> <?php echo e($manager->patronymic); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <svg class="" fill="#000000" width="64px" height="64px" viewBox="-3.2 -3.2 38.40 38.40" version="1.1" xmlns="http://www.w3.org/2000/svg" transform="matrix(1, 0, 0, 1, 0, 0)rotate(0)"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round" stroke="#CCCCCC" stroke-width="0.064"></g><g id="SVGRepo_iconCarrier"> <path d="M0.256 8.606c0-0.269 0.106-0.544 0.313-0.75 0.412-0.412 1.087-0.412 1.5 0l14.119 14.119 13.913-13.912c0.413-0.412 1.087-0.412 1.5 0s0.413 1.088 0 1.5l-14.663 14.669c-0.413 0.413-1.088 0.413-1.5 0l-14.869-14.869c-0.213-0.213-0.313-0.481-0.313-0.756z"></path> </g></svg>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <input type="date" value="<?php echo e($reportDiscipline->planned_delivery_date); ?>" name="planned_delivery_date">
                                </div>
                            </td>

                            <td class="w-[100px]">
                                <div class="flex items-center !flex-row justify-between">
                                    <button type="submit"
                                            class="text-white rounded px-4 bg-red-500  hover:bg-blue-700"
                                            value="delete" name="value">Удалить
                                    </button>
                                    <button type="submit" class="text-white rounded px-4 bg-green-500 hover:bg-blue-700"
                                            value="edit" name="value">Изменить
                                    </button>
                                </div>

                            </td>
                        </form>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        <div class="mt-8 paginate__block">
            <?php echo e($reportDisciplines->withQueryString()->links()); ?>

        </div>
        <?php if($reportDisciplines->isEmpty()): ?>
            <p class="my-8 text-xl">По вашему запросу ничего не найдено!</p>
        <?php endif; ?>
        <div class="form__overlay min-h-screen w-full fixed left-0 top-0 flex justify-center items-center hidden">
            <form action="<?php echo e(route('report-disciplines.create')); ?>" method="post" class="createForm mx-auto flex flex-col gap-2 relative ">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="discipline_id">Дисциплина</label>
                    <select name="discipline_id" id="discipline_id" class="border-none">
                        <?php $__currentLoopData = $disciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($discipline->id); ?>" name="discipline_id"><?php echo e($discipline->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
                <div>
                    <label for="report_id">Вид отчета</label>
                    <select name="report_id" id="report_id" class="border-none">

                        <?php $__currentLoopData = $reportTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($reportType->id); ?>" name="report_id"><?php echo e($reportType->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
                <div>
                    <label for="group_id">Группа</label>
                    <select name="group_id" id="group_id" class="border-none">
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>" name="group_id"><?php echo e($group->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
                <div>
                    <label for="user_id">Руководитель</label>
                    <select name="user_id" id="user_id" class="border-none">
                        <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($manager->id); ?>" name="user_id"><?php echo e($manager->surname); ?> <?php echo e($manager->name); ?> <?php echo e($manager->patronymic); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
                <div>
                    <label for="planned_delivery_date">Запланированная дата</label>
                    <input type="date" name="planned_delivery_date" id="planned_delivery_date">
                </div>

                <div class="flex flex-col gap-2">

                    <a href="" class="createForm__close absolute">
                        <svg fill="#000000" width="40px" height="40px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M16.707,8.707,13.414,12l3.293,3.293a1,1,0,1,1-1.414,1.414L12,13.414,8.707,16.707a1,1,0,1,1-1.414-1.414L10.586,12,7.293,8.707A1,1,0,1,1,8.707,7.293L12,10.586l3.293-3.293a1,1,0,1,1,1.414,1.414Z"/></svg>
                    </a>
                    <button type="submit">Создать</button>
                </div>
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\gg\resources\views/reportDisciplines/index.blade.php ENDPATH**/ ?>